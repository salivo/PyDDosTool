var i = 0;
var AttackType = 1;
function menuFunction() {

if(i == 0){
    document.querySelector(".menu").classList.add("menuOpen");
    document.querySelector(".menu").classList.remove("menuClose");
    document.querySelector(".container").classList.add("change");
    document.querySelector(".tBox2").classList.add("getOff");
    document.querySelector(".tBox2").classList.remove("getOn");
    i = 1;
    }
else{
    document.querySelector(".menu").classList.remove("menuOpen");
    document.querySelector(".menu").classList.add("menuClose");
    document.querySelector(".tBox2").classList.remove("getOff");
    document.querySelector(".tBox2").classList.add("getOn");
    document.querySelector(".container").classList.remove("change");
    i = 0;
    }
}
function menuClose(){
if(i == 1){
    document.querySelector(".menu").classList.remove("menuOpen");
    document.querySelector(".menu").classList.add("menuClose");
    document.querySelector(".tBox2").classList.remove("getOff");
    document.querySelector(".tBox2").classList.add("getOn");
    document.querySelector(".container").classList.remove("change");
    i = 0;
    }
}

function OpenDocker(){
document.querySelector(".Docker").classList.add("DockerOpen");
document.querySelector(".Docker").classList.remove("DockerClose");
AttackType = 1;
}
function CloseDocker(){
document.querySelector(".Docker").classList.add("DockerClose");
document.querySelector(".Docker").classList.remove("DockerOpen");
}






function OpenHelpme(){
document.querySelector(".helpme").classList.add("DockerOpen");
document.querySelector(".helpme").classList.remove("DockerClose");
AttackType = 0;
}
function CloseHelpme(){
document.querySelector(".helpme").classList.add("DockerClose");
document.querySelector(".helpme").classList.remove("DockerOpen");
}
function StartDocker() {
    if(AttackType == 1){
    pywebview.api.StartDocker(document.querySelector("#DockerSite").value, document.querySelector("#DockerPort").value, document.querySelector("#DockerCod").value, document.querySelector("#DockerTime").value, document.querySelector("#DockerTimeType").value, document.querySelector("#DockerRequest").value);
    }
}
function StopDocker() {
if(AttackType == 1){
pywebview.api.StopDocker();
}
}